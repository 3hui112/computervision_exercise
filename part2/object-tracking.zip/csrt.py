# 1. 필요한 라이브러리 가져오기
import []

# 2. KCF 추적기 만들기
tracker = []

# 3. 비디오 파일 열기
video = []
ok, frame = []


# 4. ROI 선택
bbox = []

# 5. 선택한 ROI로 트래커 초기화
ok = []

# 6. 객체를 추적하기 위해 각 프레임을 반복
while True:
    ok, frame = []
    if not ok:
        break
# 7. 추적기 업데이트
    ok, bbox = []
    
# 8. 추적 결과 그리기
    if ok:
        (x, y, w, h) = [int(v) for v in bbox]
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0,255,0), 2, 1)
    else:
        cv2.putText(frame, 'Error', (100, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2)
# 9. 프레임 표시
    cv2.[]

# 10. 키를 누를 때 루프 종료
    if cv2.waitKey(1) & 0XFF == 27: # ESC
        break
# 11. 클린업
    video.release()
    cv.destroyAllWindows()
    

